<?php
	class Turnkeye_Testimonial_Block_View extends Mage_Core_Block_Template {
		
		public function getTestimonials() {
			return 'getTestimonials function';
		}
	}
?>