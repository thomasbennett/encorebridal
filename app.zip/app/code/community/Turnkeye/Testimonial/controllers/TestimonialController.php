<?php
	class Turnkeye_Testimonial_TestimonialsController extends Mage_Core_Controller_Front_Action
	{
		public function mapAction()
		{
			$this->loadLayout();
			$this->renderLayout();
		}
	}
